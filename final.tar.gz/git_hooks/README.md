Copy it to `.git/hooks/`.

This pre-push hook is not panacea because for simplicity it runs tests on current state of the tree, not on the state that is being pushed. But still it's better than nothing.
