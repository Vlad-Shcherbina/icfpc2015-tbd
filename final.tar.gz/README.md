ICFPC 2015
===

 + Installation and running guedlines are [in README of tbd-playground repository](https://github.com/Vlad-Shcherbina/tbd-playground/blob/master/README.md).
 + [Guidelines for new members](https://docs.google.com/document/d/1gVkY6YPs4L8MBQY9usCRjXmp7wXSalfykFM4H2o4l2o/edit?usp=sharing).

With [Nix package manager](http://nixos.org), getting a sandbox environment with everything installed is as easy as just running ``nix-shell`` or ``nix-shell --pure``.

dependencies when installing with pip
---

nose coverage hypothesis httpie
