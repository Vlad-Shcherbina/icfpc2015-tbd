#include "sample.h"

#include <algorithm>


std::vector<int> reverse(std::vector<int> xs) {
    auto c_plus_plus = 11;

    std::reverse(xs.begin(), xs.end());
    return xs;
}
