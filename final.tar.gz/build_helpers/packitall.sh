git archive -v -o submission.tar.gz HEAD
