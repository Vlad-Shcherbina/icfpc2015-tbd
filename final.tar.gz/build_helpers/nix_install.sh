nix-env --version 2>&1 || curl https://nixos.org/nix/install | sh
