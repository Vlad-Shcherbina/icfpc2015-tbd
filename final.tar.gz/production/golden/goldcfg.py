def token():
    return 'FDNkwcESw/xyOt0x9NG89MsXgsZKLJQvS5zVIEZo78E='

def url():
    return 'https://davar.icfpcontest.org/teams/93/solutions'

def us():
    return 'http://127.0.0.1:55315'
