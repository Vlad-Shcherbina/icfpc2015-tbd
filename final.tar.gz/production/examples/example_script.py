from production.examples import example_module


def main():
    print(example_module.load_example())


if __name__ == '__main__':
    main()
