git archive -v -o submission-release.tar.gz HEAD
